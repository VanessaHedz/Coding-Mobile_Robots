/********************************************************
 *                                                      *
 *      ProyectoFinal.h            	                	*
 *                                                      *
 *		Students:	                                    *
 *          - Vanessa Hernández                         *
 *          - Alejandro Sánchez                         *
 *		FI-UNAM				                        	*
 *		06-5-2024                                       *
 *                                                      *
 ********************************************************/

#include "dijkstra.h"

void proyecto_final(int dest, int intensity, int state, int *next_state, float Mag_Advance,float max_angle, int num_sensors, coord coord_robot, coord coord_dest){
/* Parámetros:
    1- quantized_obs
    2- quantized_intensity
    3- state
    4- &next_state
    5- inputs.Mag_Advance
    6- inputs.max_angle 
    7- inputs.num_sensors
    8- coord_robot
    9- coord_dest
*/

//variables
	char room[50]; //Vector de habitaciones
	char line[100];
	char action[50];
	float room_x; //Coordenada en X de la habitación destino.
	float room_y; //Coordenada en Y de la habitación destino.
	float X[100]; //Vecotres de coordenadas de X y Y
	float Y[100];

    float final_x;
    float final_y;

	//Contadores
    int punto_destino = 0;
	int i_vectores=0;
	int i_final=0;
    int i=0;
    int j=0;

	//Flags
	bool flag_commands = false;
    bool flagOnce = false;
    bool flg_finish;
    bool flg;

 switch ( state )
 {
    case 0:
        //Read the file commands.dat
        FILE *file = fopen("/home/vane/Documents/proyecto_final_2024/commands.dat","r");
		if (file == NULL){
			perror("No se puede abrir el archivo.");
		}

		//Aquí se guardan las todas las coordenadas de las habitaciones a las que debe de ir el robot. 
		if (!flag_commands){
			// ¿En dónde se hace verdadero el flag_commands?
			while (fgets(line,sizeof(line),file)){
				if(sscanf(line, "OPERATOR go to %s %f,%f",room,&room_x,&room_y) == 3){ // Indica si se leyeron los 3 elementos exitosamente
					X[i_vectores] = room_x;
					Y[i_vectores] = room_y;
					i_vectores++;
				}
			}
			flag_commands = true;
		}

		// Comprobar si se leyeron las coordenadas:
		for(j=0; j<i; j++){
			printf("\nCOORD X: %f, COORD Y: %f", X[j], Y[j]); // Los archivos se leen exitosamente!! (ver el test_students.dat)
		}

        *next_state = 1;

        break;
    
    // ------------------------- DIJKSTRA

    case 1:
        // Se declara el nuevo punto y se determina la ruta
        coord_dest.xc = X[punto_destino];
        coord_dest.xc = Y[punto_destino];

        sp=dijkstra(coord_robot.xc,coord_robot.yc,coord_dest.xc, coord_dest.yc, inputs.path,inputs.environment,steps);
        *next_state = 2;
        break;
    
    case 2:
        // -------------- CÓDIGO PARA CUANDO SE ATORA EL ROBOT ---------------------
        *next_state = 3;
        break;

    case 3:
        //Mover al robot de un punto a otro


        if(flagOnce)
            {
            	for(i = 0; i < 200; i++) steps[i].node = -1;

				for(i=0; i < sp-1; i++){
					fprintf(fpw,"( connection %f %f %f %f )\n",steps[i].x, steps[i].y,steps[i+1].x, steps[i+1].y);
				#ifdef DEBUG
        			printf(" Node %d x %f y %f\n", steps[i].node, steps[i].x, steps[i].y);
				#endif
    			    }
		    
				fprintf(fpw,"( connection %f %f %f %f )\n",steps[i].x, steps[i].y,steps[i].x, steps[i].y);
				ii = 0;			
				final_x = coord_dest.xc;
				final_y = coord_dest.yc;
				fprintf(fpw,"( destination %f %f )\n",steps[ii].x,steps[ii].y);
				coord_dest.xc= steps[ii].x;
				coord_dest.yc=steps[ii].y;
				#ifdef DEBUG
				printf("Node %d x %f y %f\n", steps[ii].node, steps[ii].x, steps[ii].y);
				printf("First light %d: x = %f  y = %f \n",ii,steps[ii].x,steps[ii].y);
				#endif

				flagOnce = 0;
				flg_finish=0;
				state=next_state;
				DistTheta.angle=0.0;
				DistTheta.distance=0.0;
		    
            }

            else{
				if(flg == 1){
					if(flg_finish == 1){
						fprintf(fpw,"( distance %f )\n",distance1);
						fprintf(fpw,"( num_steps %d )\n",num_obs);
						fclose(fpw);
						return(num_obs);
					}
					else {
                        ii++;
                        if(steps[ii].node != -1)
                        {
							fprintf(fpw,"( destination %f %f )\n",steps[ii].x,steps[ii].y);
                			coord_dest.xc= steps[ii].x;
                    		coord_dest.yc=steps[ii].y;

                		#ifdef DEBUG
        	    			printf("Node %d x %f y %f\n", steps[ii].node, steps[ii].x, steps[ii].y);
                			printf("New Light %d: x = %f  y = %f \n",ii,steps[ii].x,steps[ii].y);
                		#endif

							flg=0;
                                //printf("type a number \n");
                                //scanf("%d",&tmp);
                            }
						else{
								fprintf(fpw,"( destination %f %f )\n",final_x,final_y);
                                coord_dest.xc= final_x;
                                coord_dest.yc= final_y;
                                printf("Final Light %d: x = %f  y = %f \n",i,final_x,final_y);
								flg=0;
                                flg_finish = 1;
							}

					    }
				    }
                state = next_state;
                DistTheta = state_machine_avoidance_destination(quantized_obs,quantized_attraction,quantized_intensity,state, &next_state,inputs.Mag_Advance,inputs.max_angle);
            }

        break;
 }
 
 //Read 

} 