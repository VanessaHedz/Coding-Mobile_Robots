/********************************************************
 *                                                      *
 *                                                      *
 *      state_machine_student.h          		*
 *                                                      *
 *		Student:				*
 *		FI-UNAM					*
 *		2-15-2024                               *
 *                                                      *
 ********************************************************/


// Student State Machine 
AdvanceAngle reactive_students(Raw observations, int dest, int intensity, float Mag_Advance, float max_angle, int num_sensors){

 AdvanceAngle gen_vector;
 int obs;
 int j;
 float left_side=0;
 float right_side=0;
 int value = 0;
 static int step=0;

 step++;
 printf("\n\n **************** Student Reactive Behavior %d *********************\n",step);

 for(j=0;j<num_sensors/2;j++){
        right_side = observations.sensors[j] + right_side;
        printf("right side sensor[%d] %f\n",j,observations.sensors[j]);
 }

 for(j=num_sensors/2;j<num_sensors;j++){
        left_side = observations.sensors[j] + left_side;
        printf("left side sensor[%d] %f\n",j,observations.sensors[j]);
 }

 right_side = right_side/(num_sensors/2);
 left_side = left_side/(num_sensors/2);
 printf("Average right side %f\n",right_side);
 printf("Average left side %f\n",left_side);

 if( left_side < THRS) value = (value << 1) + 1;
 else value = (value << 1) + 0;

 if( right_side < THRS) value = (value << 1) + 1;
 else value = (value << 1) + 0;

 obs = value;
 printf("intensity %d obstacles %d dest %d\n",intensity,obs,dest);

 if (intensity == 1){
	// Constants STOP, TURN RIGHT, ETC, are defined in ../utilities/constants.h
	// generate_output function in ../utilities/utilities.h
	gen_vector=generate_output(STOP,Mag_Advance,max_angle);
        printf("STOP\n");
	printf("\n **************** Reached light source ******************************\n");
 }
 else if (obs == 0){
	// There is not obstacle
        //gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
	//printf("FORWARD\n");

	if (dest == 0){
                // go right twice
		gen_vector=generate_output(RIGHTADVANCETWICE,Mag_Advance,max_angle);
                printf("TURN RIGHT TWICE\n");
        }
        else if (dest == 1){
                // go left twice
                gen_vector=generate_output(LEFTADVANCETWICE,Mag_Advance,max_angle);
                printf("TURN LEFT TWICE\n");
        }
        else if (dest == 2){
                 // go right
                 gen_vector=generate_output(RIGHTADVANCE,Mag_Advance,max_angle);
                 printf("TURN RIGHT\n");
        }
        else if (dest == 3){
                // go left
                gen_vector=generate_output(LEFTADVANCE,Mag_Advance,max_angle);
                printf("TURN LEFT\n");
        }
 }
 else if (obs == 1){
        // Obtacle in the right
        gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
	printf("TURN LEFT\n");
 }
 else if (obs == 2){
        // obtacle in the left
	gen_vector=generate_output(RIGHT,Mag_Advance,max_angle);
	printf("TURN RIGHT\n");
 }
 else if (obs == 3){
	// obstacle in the front
        gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
	printf("TURN LEFT\n");
 }


 return gen_vector;

}



                 


// Student State Machine 
AdvanceAngle state_machine_students(Raw observations, int dest, int intensity, int state, int *next_state, float Mag_Advance, float max_angle, int num_sensors, float angle_light){

 AdvanceAngle gen_vector;
 int obs;
 int j;
 float left_side=0;
 float right_side=0;
 int value = 0;

 printf("\n\n **************** Student State Machine *********************\n");

 for(j=0;j<num_sensors/2;j++){
        right_side = observations.sensors[j] + right_side;
        printf("right side sensor[%d] %f\n",j,observations.sensors[j]);
 }

 for(j=num_sensors/2;j<num_sensors;j++){
        left_side = observations.sensors[j] + left_side;
        printf("left side sensor[%d] %f\n",j,observations.sensors[j]);
 }

 right_side = right_side/(num_sensors/2);
 left_side = left_side/(num_sensors/2);
 printf("Average right side %f\n",right_side);
 printf("Average left side %f\n",left_side);

 if( left_side < THRS) value = (value << 1) + 1;
 else value = (value << 1) + 0;

 if( right_side < THRS) value = (value << 1) + 1;
 else value = (value << 1) + 0;

 obs = value;
 printf("intensity %d obstacles %d dest %d\n",intensity,obs,dest);
 printf("Angle light %f\n",angle_light);

 switch ( state ) {

        case 0:
                if (intensity == 1){
                        gen_vector=generate_output(STOP,Mag_Advance,max_angle);
                        *next_state = 1;

                        printf("Present State: %d STOP\n", state);
			printf("\n **************** Reached light source ******************************\n");
                }
                else{

			gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                        *next_state = 1;

                        printf("Present State: %d FORWARD\n", state);
                }

                break;

        case 1:
                if (obs == 0){
			// There is not obstacle
                        gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                        *next_state = 13;

                        printf("Present State: %d FORWARD\n", state);
                }
                else{
                        gen_vector=generate_output(STOP,Mag_Advance,max_angle);
                        printf("Present State: %d STOP\n", state);

                        if (obs == 1){
                                // obtacle in the  right
                                *next_state = 2;
                        }
                        else if (obs == 2){
                                // obtacle in the left
                                *next_state = 4;
                        }
                        else if (obs == 3){
				// obstacle in the front
                                *next_state = 6;
                        }
                }

                break;

        case 2: // Backward, obstacle in the right
                gen_vector=generate_output(BACKWARD,Mag_Advance,max_angle);
                *next_state = 3;

		printf("Present State: %d BACKWARD, obstacle right\n", state);
                break;

        case 3: // right turn
                gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
                *next_state = 0;

		printf("Present State: %d TURN LEFT\n", state);
                break;

        case 4: // Backward, obstacle in the left
                gen_vector=generate_output(BACKWARD,Mag_Advance,max_angle);
                *next_state = 5;

		printf("Present State: %d BACKWARD, obstacle left\n", state);
                break;

        case 5: // left turn
                gen_vector=generate_output(RIGHT,Mag_Advance,max_angle);
                *next_state = 0;

		printf("Present State: %d TURN RIGTH\n", state);
                break;

        case 6: // Backward, obstacle in front
                gen_vector=generate_output(BACKWARD,Mag_Advance,max_angle);
                *next_state = 7;

		printf("Present State: %d BACKWARD, obstacle FRONT\n", state);
                break;

	case 7: /// Left turn
                gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
                *next_state = 8;

		printf("Present State: %d TURN 1 LEFT\n", state);
                break;

        case 8:// Left turn
                gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
                *next_state = 9;

		printf("Present State: %d TURN 2 LEFT\n", state);
                break;

        case 9: // Forward
                gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                *next_state = 10;

                printf("Present State: %d 1 FORWARD\n", state);
                break;

        case 10: // Forward
                gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                *next_state = 11;

                printf("Present State: %d 2 FORWARD\n", state);
                break;

	case 11: // Right turn
                gen_vector=generate_output(RIGHT,Mag_Advance,max_angle);
                *next_state = 12;

                printf("Present State: %d turn 1 RIGHT\n", state);
                break;

        case 12: // Right turn
                gen_vector=generate_output(RIGHT,Mag_Advance,max_angle);
                *next_state = 0;

                printf("Present State: %d turn 2 RIGHT\n", state);
                break;


        case 13: // // check destination
		 if (dest == 0){
                                // go right
                                gen_vector=generate_output(RIGHT,Mag_Advance,max_angle);
                                *next_state = 5;

                                printf("Present State: %d RIGHT\n", state);
                 }
                 else if (dest == 1){
                                // go left
                                gen_vector=generate_output(LEFT,Mag_Advance,max_angle);
                                *next_state = 3;

                                printf("Present State: %d LEFT\n", state);
                 }
                 else if (dest == 2){
                                // go right single
                                gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                                *next_state = 5;

                                printf("Present State: %d FORWARD\n", state);
                 }
                 else if (dest == 3){
                                // go left single
                                gen_vector=generate_output(FORWARD,Mag_Advance,max_angle);
                                *next_state = 3;

                                printf("Present State: %d FORWARD\n", state);
                 }
                break;

	default:
		printf("State %d not defined used ", state);
                gen_vector=generate_output(STOP,Mag_Advance,max_angle);
                next_state = 0;
                break;

                
 }

 return gen_vector;

}

// Campos potenciales 3 -- Alejandro
AdvanceAngle Campos_P3(Raw observations, float dest_angle, float distance, coord coord_robot, int intensity, int a, int *next_a, float xq, float *next_xq, float yq, float *next_yq, float Mag_Advance, float max_angle, int num_sensors, float angle_start, float angle_end, int dest, int obs){

 AdvanceAngle gen_vector;
 //int obs;
 int j,l=0,m=0; //variable por si encuentra un obstaculo
 float d;
 float angulo, angulo1;
 float left_side=0;
 float right_side=0;
 int state;
 int next_state;
 int value = 0;
 float e1 = 100;
 float x,xd,xo,y,yd,yo,xq1,yq1;
 int caso=5;
 float Fx,Fy,fx,fy,fx1,fy1, dobs, FRx,FRy, FAx,FAy;
 float d0=5.0, n = 0.05, obst_angle=3.14, mod;
 float r1,r2,r3,r4,modr,ks,ns,k1;
 coord coord_obs;
 coord coord_cer;
 coord next_coord_cer;
 x =coord_robot.xc;
 y =coord_robot.yc;
 
 d=distance;

 //dobs=10;

 k1=(abs(angle_start)+abs(angle_end));
 ns= num_sensors;
 ks=k1/ns;
 printf("k1 k: %f, %f \n",k1, ks);


 for(j=0;j<num_sensors;j++){

	if(observations.sensors[j] < 0.1 && (observations.sensors[j] < observations.sensors[j-1])){
		dobs=observations.sensors[j];
		obst_angle=angle_start+(j*ks);
		l=1;
		printf("Angulos1: %f, %f, %f \n", obst_angle, angle_start, angle_end);
		printf("j k: %d, %f \n", j, ks);
		xo=dobs*cos(obst_angle); 
		yo=dobs*sin(obst_angle); 
		
	}
	else if(l!=1){
		printf("Anguloss: %f \n", obst_angle);
		xo=0; 
		yo=0; 

	}	
 }

 
 next_coord_cer=coord_robot;
 xd=d*cos(dest_angle); 
 yd=d*sin(dest_angle);

 printf("xobs, yobs: %f, %f \n", xo, yo);

 if (a!=1) {

 	xq=0;
	yq=0;
	*next_a=1;
 
 }

 if (intensity == 1){
         gen_vector=generate_output(STOP,Mag_Advance,max_angle);
         printf("Present State: STOP\n");		
 }
 else{

 	 //x=xq;
	 //y=yq; 

	 printf("\n\n **************** Student reactive Campos *********************\n");

	 //U=(1/2)*e1*(((x-xd)*(x-xd))+((y-yd)*(y-yd)));

	 modr= sqrt(((x-xo)*(x-xo))+((y-yo)*(y-yo)));

	 r1 = ((1/modr)-(1/d0));
	 r2 = (1/(modr*modr));
	 r3 = ((x-xo)/modr);
	 r4 = ((y-yo)/modr);

	 printf("rs: %f, %f, %f, %f \n", r1,r2,r3,r4);
	 printf("xobs, yobs: %f, %f \n", d, dest_angle);
	 FRx=(-n)*r1*r2*r3;
	 FRy=(-n)*r1*r2*r4;

	 if(modr>d0 | (xo==0 && l!=1)){

	 	FRx=0;
		FRy=0;
	 }
	 else if(xo==0){

		m=1;

	 }

	 printf("Fuerza de repulsion: %f , %f \n", FRx,FRy);

	 //F=e1*((x-xd),(y-yd));
	 FAx= e1*(x-xd);
	 FAy= e1*(y-yd);

	 Fx= FRx+FAx;
	 Fy= FRy+FAy;

	 mod = (sqrt(((Fx)*(Fx))+((Fy)*(Fy))));

	 fx=Fx/mod;
	 fy=Fy/mod;

	 printf("Fuerza de atraccion: %f , %f \n", FAx,FAy);
	 printf("Fuerza total: %f , %f \n", Fx,Fy);
	 printf("Fuerza total m: %f , %f, %f \n", fx,fy, mod);

	 *next_xq=x-(Mag_Advance*fx);
	 *next_yq=y-(Mag_Advance*fy);

	 xq=x-(Mag_Advance*fx);
	 yq=y-(Mag_Advance*fy);

	 printf("Posicion actual: %f , %f \n", x,y);
	 printf("Posicion siguiente: %f , %f \n", xq,yq);
	 
	 angulo=atan(yq/xq);

	 if(xo<0 && yo<0){
		angulo=0-atan(yq/xq);
	 }
	 if(xo>0 && yo>0){
		angulo=0-atan(yq/xq);
	 }
	 else if(xo<0){
		angulo=0-atan(yq/xq);
	 }

	 else if(m==1){

	 	angulo=3.1415;
		printf("MMMMMMMMMMMM \n");

	 }
	 
	 //*next_coord_per = coord_robot;

	  if(FRx==0){
		mod = (sqrt(((FAx)*(FAx))+((FAy)*(FAy))));
		fx=FAx/mod;
		fy=FAy/mod;
		xq=x-(Mag_Advance*fx);
		yq=y-(Mag_Advance*fy);

	 	angulo=atan(yq/xq);

		if((xq<0 && yq<0) | xq<0){

			angulo=3.1415+atan(yq/xq);		
		
		}
		printf("Posicion actual: %f , %f \n", x,y);
		printf("Posicion siguiente: %f , %f \n", xq,yq);
		printf("Angulos: %f, %f \n", angulo, dest_angle);
		gen_vector=generate_output(caso,Mag_Advance,dest_angle);
		printf("Holas \n");
	 }
	 else{
		printf("Angulos: %f, %f \n", angulo, dest_angle);
	 	gen_vector=generate_output(caso,Mag_Advance,angulo);

	 }
 }


 return gen_vector;

}



                 

